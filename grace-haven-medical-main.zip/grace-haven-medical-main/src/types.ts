export interface RouteParams {
  params: {
    lang: string;
  }
}
